public interface B {

    void aa();

    Object pp();
}
