public interface C {

    double ee();

    Object gg();
}
