public class C extends null {

    double ee();

    Object gg();
}
