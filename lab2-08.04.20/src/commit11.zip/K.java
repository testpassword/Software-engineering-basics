public class K extends null {

    void bb();

    long dd();
}
