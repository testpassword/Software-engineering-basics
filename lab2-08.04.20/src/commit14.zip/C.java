public class C extends null {

    double ee();

    Object gg();

    public void ab() {
        System.out.println();
    }
}
