public interface E {

    int cc();

    String kk();
}
