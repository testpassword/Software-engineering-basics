public interface K {

    void bb();

    long dd();
}
