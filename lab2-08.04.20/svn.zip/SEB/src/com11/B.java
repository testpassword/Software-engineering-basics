public class B extends null {

    void aa();

    Object pp();
}
