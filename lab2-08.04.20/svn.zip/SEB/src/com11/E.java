public class E extends null {

    int cc();

    String kk();
}
