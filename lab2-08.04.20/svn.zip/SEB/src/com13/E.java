public class E extends null {

    int cc();

    String kk();

    public void bb() {
        System.out.println(getClass().getName());
    }
}
