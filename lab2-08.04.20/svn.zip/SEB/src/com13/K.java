public class K extends null {

    void bb();

    long dd();

    public Object gg() {
        return return getClass().getClassLoader();
    }
}
